const $ = (id) => document.getElementById(id);
let mode = "image";
let resultUrl = null;
let selectedFile = null;

document.querySelectorAll(".tab").forEach(button => {
  button.addEventListener("click", () => {
    mode = button.dataset.mode;
    document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b === button));
    $("imageOptions").classList.toggle("hidden", mode !== "image");
    $("videoOptions").classList.toggle("hidden", mode !== "video");
    $("generate").textContent = mode === "image" ? "Create image ✨" : "Create video 🎬";
    $("resultType").textContent = mode.toUpperCase();
    $("status").textContent = mode === "image"
      ? "Image mode selected. Connect a compatible backend to generate."
      : "Video mode selected. A video-capable backend workflow is required.";
  });
});

$("sourceImage").addEventListener("change", e => {
  selectedFile = e.target.files?.[0] || null;
});

function backendUrl() {
  return ($("backend").value || localStorage.getItem("awakensam_backend") || "").trim().replace(/\/+$/, "");
}
$("backend").value = localStorage.getItem("awakensam_backend") || "";
$("saveBackend").addEventListener("click", () => {
  const value = $("backend").value.trim().replace(/\/+$/, "");
  if (value && !/^https?:\/\//i.test(value)) {
    $("backendStatus").textContent = "Enter a full URL beginning with https:// or http://";
    return;
  }
  if (value) localStorage.setItem("awakensam_backend", value);
  else localStorage.removeItem("awakensam_backend");
  $("backendStatus").textContent = value ? "Backend URL saved on this device." : "Backend URL cleared.";
});

$("generate").addEventListener("click", async () => {
  const prompt = $("prompt").value.trim();
  if (!prompt) {
    $("status").textContent = "Write a prompt first.";
    $("prompt").focus();
    return;
  }
  const base = backendUrl();
  if (!base) {
    $("status").textContent = "No AI backend is connected yet. This starter is the interface; follow README.md to connect a real model server.";
    return;
  }
  $("generate").disabled = true;
  $("status").textContent = "Sending request to your backend…";
  try {
    let response;
    if (mode === "image") {
      response = await fetch(`${base}/api/generate/image`, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({
          prompt,
          style: $("style").value,
          aspect_ratio: $("ratio").value,
          steps: Number($("steps").value),
          seed: $("seed").value === "" ? null : Number($("seed").value)
        })
      });
    } else {
      const form = new FormData();
      form.append("prompt", prompt);
      form.append("style", $("style").value);
      form.append("aspect_ratio", $("ratio").value);
      if (selectedFile) form.append("image", selectedFile);
      response = await fetch(`${base}/api/generate/video`, {method:"POST", body:form});
    }
    if (!response.ok) {
      const detail = await response.text();
      throw new Error(`Backend returned ${response.status}: ${detail.slice(0,300)}`);
    }
    const data = await response.json();
    if (!data.url) throw new Error("Backend response must contain a 'url' field pointing to the generated media.");
    resultUrl = new URL(data.url, base).href;
    showResult(resultUrl, data.media_type || (mode === "image" ? "image" : "video"));
    $("status").textContent = "Finished. Your media is ready.";
  } catch (error) {
    $("status").textContent = `Could not generate: ${error.message}. Check backend URL, CORS and model workflow.`;
  } finally {
    $("generate").disabled = false;
  }
});

function showResult(url, type) {
  const preview = $("preview");
  preview.replaceChildren();
  const media = document.createElement(type.startsWith("video") ? "video" : "img");
  media.src = url;
  if (media.tagName === "VIDEO") {
    media.controls = true;
    media.playsInline = true;
  } else {
    media.alt = "AI generated result";
  }
  preview.append(media);
  $("download").disabled = false;
}
$("download").addEventListener("click", async () => {
  if (!resultUrl) return;
  const a = document.createElement("a");
  a.href = resultUrl;
  a.download = mode === "image" ? "awakensam-image.png" : "awakensam-video.mp4";
  a.target = "_blank";
  a.rel = "noopener";
  a.click();
});
$("copyPrompt").addEventListener("click", async () => {
  const text = `${$("prompt").value}\nStyle: ${$("style").value}\nAspect ratio: ${$("ratio").value}`;
  try {
    await navigator.clipboard.writeText(text);
    $("status").textContent = "Prompt copied.";
  } catch {
    $("prompt").select();
    $("status").textContent = "Select and copy your prompt manually.";
  }
});

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
