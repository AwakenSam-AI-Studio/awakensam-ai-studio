# AwakenSam AI Studio (mobile-first starter)

This is a responsive website/PWA interface designed to be usable from an Android phone. It includes image/video modes, prompts, style and aspect-ratio controls, a preview area, download button, and a configurable backend URL.

## Important: what works now, and what needs an AI engine

- The frontend works as a website and can be installed as a PWA on Android when served over HTTPS.
- It does **not** generate AI media by itself. It sends requests to a backend you control.
- The frontend expects:
  - `POST /api/generate/image` JSON: `{prompt, style, aspect_ratio, steps, seed}` and a JSON response `{url, media_type:"image/png"}`
  - `POST /api/generate/video` multipart form: `prompt`, `style`, `aspect_ratio`, optional `image`, and a JSON response `{url, media_type:"video/mp4"}`
- No API keys are stored in the frontend. Do not expose private keys in public JavaScript.
- Free static hosting does not provide a free GPU. Truly no-per-generation-fee generation generally means running compatible open-weight models on your own hardware. Since your current device is a phone, use the phone to edit/deploy the app and initially connect to a separate model host you control. Free cloud GPU access is quota-limited and can change.

## Fastest setup using only your phone

1. Download and extract `awakensam_ai_studio.zip`.
2. Open GitHub in your phone browser and create a new **public** repository named `awakensam-ai-studio` (or keep it private if your account/hosting supports your chosen method).
3. Upload `index.html`, `style.css`, `app.js`, `manifest.webmanifest`, and `sw.js` to the repository root.
4. In the repository, open **Settings → Pages** and publish from the main branch/root if available.
5. Open the published HTTPS website on Android Chrome. Use Chrome menu → **Add to Home screen** (wording varies) to install it like an app.
6. The site UI works, but real generation remains disabled until a compatible backend is configured.

## Add a real AI backend

### Recommended open-source engine: ComfyUI

- Project: https://github.com/Comfy-Org/ComfyUI
- ComfyUI can run supported open models and expose workflows through its API.
- Run it on a computer you control, or a server with suitable GPU. A phone-only device is not a practical host for large video models.
- Build an image workflow and a video workflow in ComfyUI. Export each using **Save (API Format)** / API workflow export, then implement backend routes that submit prompts to those workflows, poll job status, and return a safe media URL.
- For video, use a video-capable workflow/model such as a compatible Wan or LTX-Video workflow. Exact nodes and hardware needs depend on model version.

### Suggested model families

- Images: Stable Diffusion 1.5, SDXL, or another compatible open-weight image model.
- Video: Wan 2.1/2.2 or LTX-Video, depending on available memory and model licence.
- Model weights can have different licences and usage terms. Check the exact model card before commercial use.

References:
- ComfyUI: https://github.com/Comfy-Org/ComfyUI
- Diffusers docs: https://huggingface.co/docs/diffusers
- Hugging Face Spaces hosting limits: https://huggingface.co/docs/hub/spaces-overview

## Backend contract example

Image request:
```json
{
  "prompt": "Cinematic Narasimha Avatar emerging from a palace pillar",
  "style": "Devotional Cinema",
  "aspect_ratio": "9:16",
  "steps": 30,
  "seed": null
}
```

Successful image response:
```json
{"url":"/media/result-123.png","media_type":"image/png"}
```

Successful video response:
```json
{"url":"/media/result-456.mp4","media_type":"video/mp4"}
```

Your backend must also:
- validate prompt size and aspect ratio;
- queue long-running generation jobs instead of blocking HTTP requests;
- return media URLs that the browser can access;
- configure CORS only for your website origin;
- impose file-size limits for uploads;
- avoid accepting arbitrary workflow JSON from public users;
- keep any private credentials on the server.

## Next milestones

1. Publish the PWA interface.
2. Add an image-generation backend first.
3. Add image-to-video with a compatible ComfyUI workflow.
4. Add Hindi text-to-speech and FFmpeg assembly.
5. Wrap the PWA in a Trusted Web Activity or use a Capacitor-based Android shell when ready.

This project intentionally avoids pretending that a frontend alone is an AI model or that free cloud GPU compute is unlimited.
